"use client";
import { useEffect, useState } from "react";
import axios from "axios";
import { usePathname } from "next/navigation";

export default function Article() {
  const [article, setArticle] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const pathname = usePathname();
  const slug = pathname.split("/").pop(); // Extraemos el slug desde la URL

  useEffect(() => {
    const fetchArticle = async () => {
      setIsLoading(true);
      try {
        console.log(`Fetching article with slug: ${slug}`);
        const response = await axios.get(
          `http://localhost:1337/api/articles?filters[slug][$eq]=${slug}`
        );
        console.log("API response:", response.data);

        if (response.data.data && response.data.data.length > 0) {
          setArticle(response.data.data[0]); // Accedemos al primer artículo en el array
        } else {
          console.error("Article not found");
        }
        setIsLoading(false);
      } catch (error) {
        console.error("Error fetching article:", error);
        setIsLoading(false);
      }
    };

    fetchArticle();
  }, [slug]);

  if (isLoading) return <p>Loading...</p>;
  if (!article) return <p>No article found</p>;

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-4xl font-bold mb-4">{article.title}</h1>
      <p className="text-lg mb-8">{article.description}</p>
    </div>
  );
}
